"""
Constants used across the application
"""
from enum import Enum


class IndianState(str, Enum):
    """Indian states and union territories with their codes"""
    AN = "Andaman and Nicobar Islands"
    AP = "Andhra Pradesh"
    AR = "Arunachal Pradesh"
    AS = "Assam"
    BR = "Bihar"
    CG = "Chhattisgarh"
    CH = "Chandigarh"
    DN = "Dadra and Nagar Haveli and Daman and Diu"
    DL = "Delhi"
    GA = "Goa"
    GJ = "Gujarat"
    HR = "Haryana"
    HP = "Himachal Pradesh"
    JK = "Jammu and Kashmir"
    JH = "Jharkhand"
    KA = "Karnataka"
    KL = "Kerala"
    LA = "Ladakh"
    LD = "Lakshadweep"
    MP = "Madhya Pradesh"
    MH = "Maharashtra"
    MN = "Manipur"
    ML = "Meghalaya"
    MZ = "Mizoram"
    NL = "Nagaland"
    OR = "Odisha"
    PY = "Puducherry"
    PB = "Punjab"
    RJ = "Rajasthan"
    SK = "Sikkim"
    TN = "Tamil Nadu"
    TS = "Telangana"
    TR = "Tripura"
    UP = "Uttar Pradesh"
    UK = "Uttarakhand"
    WB = "West Bengal"


# State code mapping for convenience
INDIAN_STATES_MAP = {
    'AN': 'Andaman and Nicobar Islands',
    'AP': 'Andhra Pradesh',
    'AR': 'Arunachal Pradesh',
    'AS': 'Assam',
    'BR': 'Bihar',
    'CG': 'Chhattisgarh',
    'CH': 'Chandigarh',
    'DN': 'Dadra and Nagar Haveli and Daman and Diu',
    'DL': 'Delhi',
    'GA': 'Goa',
    'GJ': 'Gujarat',
    'HR': 'Haryana',
    'HP': 'Himachal Pradesh',
    'JK': 'Jammu and Kashmir',
    'JH': 'Jharkhand',
    'KA': 'Karnataka',
    'KL': 'Kerala',
    'LA': 'Ladakh',
    'LD': 'Lakshadweep',
    'MP': 'Madhya Pradesh',
    'MH': 'Maharashtra',
    'MN': 'Manipur',
    'ML': 'Meghalaya',
    'MZ': 'Mizoram',
    'NL': 'Nagaland',
    'OR': 'Odisha',
    'PY': 'Puducherry',
    'PB': 'Punjab',
    'RJ': 'Rajasthan',
    'SK': 'Sikkim',
    'TN': 'Tamil Nadu',
    'TS': 'Telangana',
    'TR': 'Tripura',
    'UP': 'Uttar Pradesh',
    'UK': 'Uttarakhand',
    'WB': 'West Bengal',
}
